package com.team2.fabackend.domain.advice;

import java.time.LocalDate;
import java.util.Map;

public class Advice {
    private LocalDate date;
    private Map<String, Integer> currentSpends;
    private Map<String, Integer> setSpends;
}
