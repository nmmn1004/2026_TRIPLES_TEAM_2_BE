package com.team2.fabackend.domain.user;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserDeleteReasonRepository extends JpaRepository<UserDeleteReason, Long> {

}
