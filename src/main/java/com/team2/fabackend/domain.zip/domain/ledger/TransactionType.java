package com.team2.fabackend.domain.ledger;

public enum TransactionType {
    INCOME, //수입
    EXPENSE, //지출
    TRANSFER //이체
}
